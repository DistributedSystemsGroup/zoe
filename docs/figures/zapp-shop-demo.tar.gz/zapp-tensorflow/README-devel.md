# TensorFlow image

This is a preliminary image for TensorFlow. It is used by Zoe, the Container Analytics as a
Service system to create a very simple TensorFlow batch service.

Zoe can be found at: https://github.com/DistributedSystemsGroup/zoe

## Setup

The Dockerfile runs a start script that:

* Launches your TensorFlow program until termination
* Launches a TensorBoard instance to inspect the output of your program

