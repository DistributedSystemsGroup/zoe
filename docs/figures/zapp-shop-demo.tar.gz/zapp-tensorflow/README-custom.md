# Batch TensorFlow

Stand-alone batch TensorFlow version 1.3 for Python 3, recompiled with instructions for modern x86_64 Intel CPUs.

This ZApp expects as parameter the command to run, relative to the workspace. For example, if you want to run
the script `~/algo/run.py`, you can write `python3 ./algo/run.py`.

