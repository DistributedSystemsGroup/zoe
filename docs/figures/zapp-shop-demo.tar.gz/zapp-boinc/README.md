# BOINC ZApp

Maintainer: Daniele Venzano <daniele.venzano@eurecom.fr>

URL: [https://gitlab.eurecom.fr/zoe-apps/zapp-boinc](https://gitlab.eurecom.fr/zoe-apps/zapp-boinc)

A ZApp for running a single [BOINC](https://boinc.berkeley.edu/) task. Run as many as you want, in parallel!
