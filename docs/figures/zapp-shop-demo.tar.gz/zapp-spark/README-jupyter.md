# Spark ZApp

URL: [https://gitlab.eurecom.fr/zoe-apps/zapp-spark](https://gitlab.eurecom.fr/zoe-apps/zapp-spark)

Combine the full power of a distributed [Apache Spark](http://spark.apache.org) cluster with Python Jupyter Notebooks.

The Spark shell can be used from the built-in terminal in the notebook ZApp.

Spark is configured in stand-alone, distributed mode. This ZApp contains Spark version 2.1.0.

