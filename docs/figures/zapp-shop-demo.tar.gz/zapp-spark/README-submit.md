# Spark ZApp

URL: [https://gitlab.eurecom.fr/zoe-apps/zapp-spark](https://gitlab.eurecom.fr/zoe-apps/zapp-spark)

Traditional Spark submit jobs. Use the command-line parameter to specify which Python or JAR file to execute from your workspace.
