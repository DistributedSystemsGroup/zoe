# Jupyter Notebook Scientific Python Stack + Tensorflow

Maintainer: Daniele Venzano <daniele.venzano@eurecom.fr>

URL: [https://hub.docker.com/r/jupyter/tensorflow-notebook/](https://hub.docker.com/r/jupyter/tensorflow-notebook/)

* Everything in [Scipy](https://github.com/jupyter/docker-stacks/tree/master/scipy-notebook) Notebook
* Tensorflow and Keras for Python 3.x (without GPU support)

Please note that you need to retrieve the secret key from the service logs to be able to access the notebooks.

